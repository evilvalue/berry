All credit to JonahFuses, ItsBlackgear, and others in Fusion Studio, creators of "Rotten Creatures", and FreshLX, creator of "Fresh Animations"!

The pack includes edits of the mod's mob textures as well as Fresh Animations' models. Currently, Warm Zombies and Dead Beard are unchanged, though with updates are intended to be in the future.

Optifine /or/ EntityModelTextures+EntityModelFeatures is required for the model to function. Make sure this pack is placed /above/ Fresh Animations.

This pack is a fix to ensure proper operation with current EMF and ETF updates. It still requires the original pack. It does not replace the old one, it corrects it.

v12+: Mummy head follows body bob; Immortal head follows body bob; Immortal overlay fixed.
